local L = TransmogTokens.L

if GetLocale() == "frFR" then
        L["Loading item information..."] = "Chargement des informations pour les objets...";
        L["Can be exchanged for %d appearances you need."] = "Peut être échangé pour %d apparences dont vous avez besoin."
        L["Can be exchanged for 1 appearance you need."] = "Peut être échangé pour 1 apparence dont vous avez besoin."
        L["Appearances from this are class and/or spec dependant."] = "Les apparences sont dépendantes de la classe et / ou de la spécialisation."
        L["Can be exchanged for appearances you don't need."] = "Peut être échangé contre des apparences dont vous n'avez pas besoin."
        L["This token cannot be redeemed for anything."] = "Ce jeton ne peut être échangé contre quoi que ce soit."
        
        --redeem
end
